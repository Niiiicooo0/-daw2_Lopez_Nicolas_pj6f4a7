document.addEventListener("DOMContentLoaded", () => {
  const docBtn = document.getElementById("Documentation");
  const opBtn  = document.getElementById("Operations");

  if (docBtn) {
    docBtn.addEventListener("click", () => {
      window.location.href = "/eCommerce/app/cli/documentation.html";
    });
  }

  if (opBtn) {
    opBtn.addEventListener("click", () => {
      window.location.href = "/eCommerce/app/cli/operations.html";
    });
  }

  const goBtn   = document.getElementById("goBtn");
  const backBtn = document.getElementById("backBtn");
  const select  = document.getElementById("operationSelect");

  if (goBtn && select) {
    goBtn.disabled = true;
    select.addEventListener("change", () => (goBtn.disabled = !select.value));

    goBtn.addEventListener("click", () => {
      const selected = select.value;
      if (!selected) return;

      switch (selected) {
        case "createOrder":
          window.location.href = "/eCommerce/app/cli/createOrder.html";           // cli -> cli
          break;
        case "viewOrders":
          window.location.href = "/eCommerce/app/srv/viewOrders.php";      // cli -> srv (subir 1 nivel)
          break;
        case "viewOneOrder":
          window.location.href = "/eCommerce/app/cli/viewOneOrder.html";          // cli -> cli
          break;
      }
    });
  }

  if (backBtn) backBtn.addEventListener("click", () => (window.location.href = "/eCommerce/app/cli/index.html"));

  const backHome = document.getElementById("back");
  const goMenu   = document.getElementById("goMenu");
  if (backHome) backHome.addEventListener("click", () => (window.location.href = "/eCommerce/app/cli/index.html"));
  if (goMenu)   goMenu.addEventListener("click",   () => (window.location.href = "/eCommerce/app/cli/operations.html"));

  const orderForm  = document.getElementById("orderForm");
  const backToMenu = document.getElementById("backToMenu");
  const backHome2  = document.getElementById("backHome");
  const resultBox  = document.getElementById("orderResult");

  if (backToMenu) backToMenu.addEventListener("click", () => (window.location.href = "/eCommerce/app/cli/operations.html"));
  if (backHome2)  backHome2.addEventListener("click",  () => (window.location.href = "/eCommerce/app/cli/index.html"));

  const productChecks = document.querySelectorAll(".p-check");
  productChecks.forEach(chk => {
    chk.addEventListener("change", () => {
      const targetId = chk.getAttribute("data-target");
      const qtyInput = document.getElementById(targetId);
      if (!qtyInput) return;
      qtyInput.disabled = !chk.checked;
      if (!chk.checked) qtyInput.value = 1;
    });
  });

  if (orderForm) {
    orderForm.addEventListener("submit", async (e) => {
      e.preventDefault();

      const orderId  = document.getElementById("orderId").value.trim();
      const fullName = document.getElementById("fullName").value.trim();
      const address  = document.getElementById("address").value.trim();
      const email    = document.getElementById("email").value.trim();
      const phone    = document.getElementById("phone").value.trim();

      const q1 = !document.getElementById("q1").disabled ? parseInt(document.getElementById("q1").value, 10) || 0 : 0;
      const q2 = !document.getElementById("q2").disabled ? parseInt(document.getElementById("q2").value, 10) || 0 : 0;
      const q3 = !document.getElementById("q3").disabled ? parseInt(document.getElementById("q3").value, 10) || 0 : 0;
      const q4 = !document.getElementById("q4").disabled ? parseInt(document.getElementById("q4").value, 10) || 0 : 0;

      if (!orderId || !fullName || !address || !email || !phone) {
        alert("Please complete all customer fields.");
        return;
      }
      if ((q1 + q2 + q3 + q4) === 0) {
        alert("Please select at least one product and quantity.");
        return;
      }

      const body = new URLSearchParams({
        orderId, fullName, address, email, phone,
        q1: String(q1), q2: String(q2), q3: String(q3), q4: String(q4)
      });

      try {
        const resp = await fetch("/eCommerce/app/srv/saveOrder.php", {   // cli -> srv
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: body.toString()
        });

        const text = (await resp.text()).trim();

        if (resp.ok && text && !isNaN(Number(text))) {
          const total = Number(text);
          resultBox.innerHTML = `
            <div class="result-ok">
              <strong>Total price (VAT 21% included):</strong> €${total.toFixed(2)}
              <div class="result-note">Order saved successfully.</div>
            </div>`;
        } else {
          resultBox.innerHTML = `<div class="result-error">Server response: ${text || "(empty)"}.</div>`;
        }
      } catch (err) {
        resultBox.innerHTML = `<div class="result-error">Network/Server error: ${err.message}</div>`;
      }
    });
  }

  const findForm = document.getElementById('findForm');
  const res = document.getElementById('result');
  if (findForm && res) {
    const backOpsBtn  = document.getElementById('backOps');
    const backHomeBtn = document.getElementById('backHome');
    if (backOpsBtn)  backOpsBtn.onclick  = () => location.href = "/eCommerce/app/cli/operations.html";
    if (backHomeBtn) backHomeBtn.onclick = () => location.href = "/eCommerce/app/cli/index.html";

    findForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      res.innerHTML = '';
      const code = document.getElementById('code').value.trim();
      if (!code) return;

      try {
        const resp = await fetch("/eCommerce/app/srv/getOrder.php", {     // cli -> srv
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({ orderId: code }).toString()
        });

        const txt = await resp.text();
        if (!resp.ok) { res.innerHTML = `<div class="result-error">Server error: ${txt}</div>`; return; }

        let data = null;
        try { data = JSON.parse(txt); } catch { data = null; }
        if (!data) { res.innerHTML = `<div class="result-error">Invalid response: ${txt}</div>`; return; }

        const items = (data.items || []).map(it =>
          `<li>${it.qty} × ${it.name} — €${Number(it.unitPrice).toFixed(2)}</li>`
        ).join('');

        res.innerHTML = `
          <div class="result-ok">
            <strong>Order:</strong> ${data.orderId}<br/>
            <strong>Name:</strong> ${data.fullName}<br/>
            <strong>Address:</strong> ${data.address}<br/>
            <strong>Email:</strong> ${data.email}<br/>
            <strong>Phone:</strong> ${data.phone}<br/>
            <strong>Subtotal:</strong> €${Number(data.subtotal).toFixed(2)}<br/>
            <strong>VAT:</strong> ${data.vat}%<br/>
            <strong>Total (VAT incl.):</strong> €${Number(data.totalWithVAT).toFixed(2)}
            ${items ? `<ul class="list">${items}</ul>` : ''}
          </div>`;
      } catch (err) {
        res.innerHTML = `<div class="result-error">Network error: ${err.message}</div>`;
      }
    });
  }
});
